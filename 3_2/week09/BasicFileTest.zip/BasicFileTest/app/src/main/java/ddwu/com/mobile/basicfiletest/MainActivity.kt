package ddwu.com.mobile.basicfiletest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import ddwu.com.mobile.basicfiletest.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"

    val mainBinding: ActivityMainBinding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    val fileManager: FileManager by lazy {
        FileManager(applicationContext)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(mainBinding.root)

        Log.d(TAG, "Internal filesDir: ${filesDir}")
        Log.d(TAG, "Internal cacheDir: ${cacheDir}")
        Log.d(TAG, "External filesDir: ${getExternalFilesDir(null).toString()}")
        Log.d(TAG, "External cacheDir: ${externalCacheDir}")

        Log.d(TAG, fileManager.getImageFileName(resources.getString(R.string.image_url)))
        Log.d(TAG, "file name: ${fileManager.getCurrentTime()}.jpg")


        mainBinding.btnWrite.setOnClickListener {

        }

        mainBinding.btnRead.setOnClickListener {

        }


        mainBinding.btnReadInternet.setOnClickListener {

        }

        mainBinding.btnWriteImage.setOnClickListener {

        }

        mainBinding.btnReadImageFile.setOnClickListener {

        }

    }


}