package ddwu.com.mobile.alarmtest

class MyBroadcastReceiver {

}