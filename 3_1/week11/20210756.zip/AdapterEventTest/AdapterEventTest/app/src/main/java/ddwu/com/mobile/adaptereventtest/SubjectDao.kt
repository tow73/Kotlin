package ddwu.com.mobile.adaptereventtest

class SubjectDao() {
    val dataList = ArrayList<String>()

    init{
        dataList.add("모바일소프트웨어")
        dataList.add("웹서비스")
        dataList.add("네트워크")
        dataList.add("시스템프로그래밍")
        dataList.add("시스템/네트워크보안")
    }
}

